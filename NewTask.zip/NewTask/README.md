# Build Dashboard Using React + Vite + Tailwindcss

![demo](https://github.com/8kra/reactjs_dashboard/assets/115061491/4128742d-ed57-4d4e-b9ba-a535043968b2)
